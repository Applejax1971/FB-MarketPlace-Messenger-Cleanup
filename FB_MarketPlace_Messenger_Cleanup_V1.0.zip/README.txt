FB MarketPlace Messenger Cleanup — Version 1.0

WHAT IT DOES
A Chrome extension for reviewing Facebook Marketplace Selling conversations. It navigates to the Marketplace Inbox in the current tab, attempts to open Messenger and the Marketplace conversation filter, and scans conversations currently loaded in the interface. You choose a minimum age in days. Eligible conversations can be reviewed, selected, and exported to CSV. Deletion requires explicit confirmation, and processing stops when a deletion cannot be verified.

INSTALL ON WINDOWS
1. Download the ZIP and use Extract All. Do not run the installer from inside the ZIP.
2. Open the extracted folder and double-click Install.cmd.
3. Choose Yes to install the extension files, or No to cancel.
4. Choose a parent location. Setup creates a folder named FB MarketPlace Messenger Cleanup there.
5. The installer copies the installed folder path to the clipboard and opens chrome://extensions in Chrome.
6. In Chrome, turn on Developer mode, click Load unpacked, and select the newly created FB MarketPlace Messenger Cleanup folder.
7. Confirm the extension appears in Chrome. Keep the installed folder in place.

USE
1. Sign in to Facebook normally in Chrome; the extension does not ask for your password.
2. Open Facebook, click the extension, and set the minimum conversation age in days.
3. Click Scan visible conversations. If navigation closes the popup, reopen it to see results.
4. Review matches carefully. The scan only includes conversations currently available to the extension, not necessarily your entire history.
5. Optional: Export CSV or select conversations for deletion. Deletion is irreversible and requires separate confirmations. Test with one conversation first.

LIMITATIONS AND SAFETY
- Chrome requires your approval to load an unpacked extension. The Windows installer cannot silently add it.
- Facebook interface changes can break detection or scanning. A missing or ambiguous control should stop the action.
- Relative ages and weekday labels can be approximate; inspect results before deletion.
- Deleting a chat may not remove the other participant's copy.
- The extension runs against facebook.com Marketplace Inbox and uses Chrome storage for the last scan result. CSV files are saved only when you request an export.
- This software is not affiliated with or endorsed by Meta or Facebook.

SOURCE AND LICENSING
The source is included for inspection. No open-source license is granted by this package. Licensing and author attribution should be finalized only after confirming code provenance and any third-party obligations.
