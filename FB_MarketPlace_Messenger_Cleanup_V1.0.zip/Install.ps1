Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'
$folderName = 'FB MarketPlace Messenger Cleanup'
$source = Join-Path $PSScriptRoot 'Extension'
$defaultParent = [Environment]::GetFolderPath('LocalApplicationData')
function Alert([string]$message,[string]$title='FB MarketPlace Messenger Cleanup') {
  [System.Windows.Forms.MessageBox]::Show($message,$title,[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}
try {
  if (-not (Test-Path (Join-Path $source 'manifest.json'))) { throw 'Extension files are missing. Extract the entire installer ZIP before running Install.cmd.' }
  $choice = [System.Windows.Forms.MessageBox]::Show(
    'Would you like to install FB MarketPlace Messenger Cleanup Version 1.0 for Google Chrome?',
    'FB MarketPlace Messenger Cleanup - Setup',
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Question)
  if ($choice -ne [System.Windows.Forms.DialogResult]::Yes) { Alert 'No files were installed.'; exit 0 }
  $picker = New-Object System.Windows.Forms.FolderBrowserDialog
  $picker.Description = 'Choose a parent folder. Setup will create FB MarketPlace Messenger Cleanup inside it.'
  $picker.SelectedPath = $defaultParent
  $picker.ShowNewFolderButton = $true
  if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Alert 'Installation cancelled. No files were copied.'; exit 0 }
  $destination = Join-Path $picker.SelectedPath $folderName
  if (Test-Path $destination) {
    $existing = [System.Windows.Forms.MessageBox]::Show(
      "The destination folder already exists:`n$destination`n`nReplace the extension files inside it? Other files will not be deleted.",
      'Existing folder', [System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($existing -ne [System.Windows.Forms.DialogResult]::Yes) { Alert 'Installation cancelled.'; exit 0 }
  }
  New-Item -ItemType Directory -Path $destination -Force | Out-Null
  Get-ChildItem -LiteralPath $source -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $destination $_.Name) -Force
  }
  $installed = Get-Content -LiteralPath (Join-Path $destination 'manifest.json') -Raw | ConvertFrom-Json
  if ($installed.version -ne '1.0.0') { throw 'Manifest verification failed.' }
  $pathForClipboard = $destination
  [System.Windows.Forms.Clipboard]::SetText($pathForClipboard)
  $instructions = @"
Extension files were installed successfully to:
$destination

IMPORTANT: Chrome does not permit a regular local installer to silently add an unpacked extension. To finish, Chrome requires your approval:

1. Chrome Extensions will open. Turn ON Developer mode (upper-right).
2. Click Load unpacked.
3. Paste the folder path (already copied to your clipboard) into the folder chooser, then select the folder.
4. Verify FB MarketPlace Messenger Cleanup appears in Chrome.

Keep this folder in place; Chrome loads the extension directly from it.
"@
  Alert $instructions 'Setup complete - Chrome approval required'
  Start-Process explorer.exe -ArgumentList ('"' + $destination + '"')
  $chromeCandidates = @(
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LocalAppData 'Google\Chrome\Application\chrome.exe')
  )
  $chrome = $chromeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($chrome) { Start-Process -FilePath $chrome -ArgumentList 'chrome://extensions/' }
  else { Alert 'Google Chrome was not found in the usual locations. Open Chrome and go to chrome://extensions/ manually.' }
  exit 0
} catch {
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Setup error',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
  exit 1
}
