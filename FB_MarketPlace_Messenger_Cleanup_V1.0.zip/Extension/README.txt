FB MarketPlace Messenger Cleanup — Version 1.0

Chrome extension source. See the parent README.txt for installation, usage, limitations, and safety notes.
