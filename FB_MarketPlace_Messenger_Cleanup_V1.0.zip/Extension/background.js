const INBOX='https://www.facebook.com/marketplace/inbox/';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let busy=false;
async function performScan(tabId){
 let tab=await chrome.tabs.get(tabId);
 if(!tab.url?.startsWith(INBOX)){
  await chrome.tabs.update(tabId,{url:INBOX});
  let loaded=false;
  for(let n=0;n<60;n++){
   await wait(350);tab=await chrome.tabs.get(tabId);
   if(tab.status==='complete'&&tab.url?.startsWith(INBOX)){loaded=true;break;}
  }
  if(!loaded)throw Error('INBOX: timed out waiting for Marketplace Inbox to load');
 }
 let response;
 for(let n=0;n<35;n++){
  await wait(400);
  try{response=await chrome.tabs.sendMessage(tabId,{type:'prepareScan'});break;}
  catch(e){if(n===19)throw Error('Facebook page not ready. Wait for inbox to load, then scan again.');}
 }
 return response;
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
 if(msg?.type!=='scanCurrent')return false;
 (async()=>{
  if(busy)throw Error('Scan setup already in progress');
  busy=true;
  try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id)throw Error('No active Chrome tab');
  const result=await performScan(tab.id);
  await chrome.storage.local.set({lastScan:{tabId:tab.id,at:Date.now(),result}});
  return result;
  }finally{busy=false;}
 })().then(sendResponse).catch(async e=>{
  const result={error:String(e.message||e)};
  await chrome.storage.local.set({lastScan:{at:Date.now(),result}});
  sendResponse(result);
 });
 return true;
});
