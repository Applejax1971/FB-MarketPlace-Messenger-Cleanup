'use strict';
const $=id=>document.getElementById(id);
let items=[],selected=new Set();
const days=()=>Math.max(1,Math.min(3650,Math.floor(Number($('days').value)||14)));
const eligible=()=>items.filter(x=>x.ageDays>=days());
const status=s=>$('status').textContent=s;
async function send(type,extra={}){
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 if(!tab?.url?.startsWith('https://www.facebook.com/marketplace/inbox/')){throw Error('Open Marketplace Inbox in the active Chrome tab.');}
 return chrome.tabs.sendMessage(tab.id,{type,...extra});
}
function render(s){
 if(s)status(s);
 const rows=eligible();
 $('results').replaceChildren();
 for(const item of rows){
  const li=document.createElement('li');const cb=document.createElement('input');cb.type='checkbox';cb.checked=selected.has(item.key);cb.onchange=()=>cb.checked?selected.add(item.key):selected.delete(item.key);
  const label=document.createElement('label');label.append(cb,document.createTextNode(` ${item.ageDays.toFixed(1)}d — ${item.title.slice(0,105)}`));li.append(label);$('results').append(li);
 }
}
function applyScan(r){
 if(r.error){status('Scan needs attention: '+r.error);return;}
 items=r.items||[];selected.clear();$('all').checked=false;
 render(`Scanned: ${r.added} new; collected: ${items.length}; eligible: ${eligible().length}.\nMatched chat links: ${r.diagnostics?.links??'?'}; recognized dates: ${r.diagnostics?.dated??'?'}.\nMarketplace filter verified; review selections before deleting.`);
}
$('scan').onclick=async()=>{
 $('scan').disabled=true;
 status('Opening Marketplace Selling and Messenger in this tab, then scanning…');
 try{const r=await chrome.runtime.sendMessage({type:'scanCurrent'});applyScan(r);}
 catch(e){status('Scan error: '+e.message+' Reopen extension after the page loads.');}
 finally{$('scan').disabled=false;}
};

$('all').onchange=()=>{for(const x of eligible())$('all').checked?selected.add(x.key):selected.delete(x.key);render();};
$('days').onchange=()=>{selected.clear();$('all').checked=false;render(`Threshold: ${days()} days. Recheck selections.`);};
$('stop').onclick=async()=>{try{await send('stop');status('Stop requested.');}catch(e){status(e.message);}};
$('delete').onclick=async()=>{
 const chosen=eligible().filter(x=>selected.has(x.key));
 if(!chosen.length){status('Select eligible conversations first.');return;}
 if(!confirm(`DELETE ${chosen.length} Marketplace Selling conversations aged at least ${days()} days? This cannot be undone. Only currently loaded rows can be deleted. The process stops at the first unverified action.`))return;
 const phrase=prompt(`To confirm deletion of ${chosen.length} conversations, type DELETE ${chosen.length}`);
 if(phrase!==`DELETE ${chosen.length}`){status('Deletion cancelled.');return;}
 $('delete').disabled=true;status('Deletion started. Keep Facebook tab open. Use the on-page STOP button to interrupt.');
 try{const r=await send('delete',{keys:chosen.map(x=>x.key),days:days()});if(r.error)throw Error(r.error);status(`Verified deleted: ${r.deleted}. Stopped: ${r.stopped?'yes':'no'}.${r.failure?'\nReason: '+r.failure:''}\nRefresh and rescan to verify.`);const latest=await send('get');items=latest.items;selected.clear();$('all').checked=false;render();}catch(e){status('Deletion error: '+e.message);}finally{$('delete').disabled=false;}
};
$('csv').onclick=()=>{
 const rows=eligible();if(!rows.length){status('Scan first.');return;}
 const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
 const csv='age_days,title,url\r\n'+rows.map(x=>[x.ageDays,x.title,x.href].map(q).join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
 chrome.downloads.download({url,filename:'marketplace_cleanup_preview.csv',saveAs:true},()=>setTimeout(()=>URL.revokeObjectURL(url),15000));
};

// Restore the final batch summary when the popup is reopened.
(async()=>{try{const r=await send('get');if(r?.lastSummary){const x=r.lastSummary;status(`Last batch: ${x.deleted} verified deleted; stopped: ${x.stopped?'yes':'no'}.${x.failure?'\nReason: '+x.failure:''}\nRefresh and rescan to verify.`);}}catch(_e){/* Inbox may not be active yet. */}})();

// Navigation closes extension popups. Restore completed scan when reopened.
(async()=>{
 try{
  const {lastScan}=await chrome.storage.local.get('lastScan');
  if(lastScan?.result&&Date.now()-lastScan.at<10*60*1000){
   const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
   if(!lastScan.tabId||tab?.id===lastScan.tabId)applyScan(lastScan.result);
  }
 }catch(_e){}
})();
