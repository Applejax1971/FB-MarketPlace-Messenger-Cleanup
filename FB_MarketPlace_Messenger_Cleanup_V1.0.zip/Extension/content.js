(() => {
 'use strict';
 if(window.__fbMarketplaceCleanup) return;
 window.__fbMarketplaceCleanup=true;
 const seen=new Map();
 let running=false, stop=false, report=[];
 let lastFailure='';
 let lastSummary=null;
 const norm=s=>(s||'').replace(/\s+/g,' ').trim();
 const ageRE=/(?:^|\s)(\d+)\s*(min|m|h|d|w|mo|y|yr|yrs|days?|weeks?|months?|years?)\s*$/i;
 const units={min:1/1440,m:1/1440,h:1/24,d:1,w:7,mo:30,y:365,yr:365,yrs:365,day:1,days:1,week:7,weeks:7,month:30,months:30,year:365,years:365};
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const validPage=()=>location.hostname==='www.facebook.com' && location.pathname.startsWith('/marketplace/inbox');
 function selling(){return [...document.querySelectorAll('[role="tab"],a,button')].some(el=>norm(el.innerText)==='Selling'&&(el.getAttribute('aria-selected')==='true'||el.getAttribute('aria-current')==='page'||!!el.closest('[aria-selected="true"]')));}
 function age(s){
  const t=norm(s), m=t.match(ageRE);
  if(m)return Number(m[1])*(units[m[2].toLowerCase()]??NaN);
  // Facebook sometimes replaces 3d/4d with weekday labels. Use a
  // conservative lower bound (whole calendar days minus one), never a
  // guessed exact age. This excludes boundary-day conversations.
  const wd=t.match(/(?:^|\s)(Sun(?:day)?|Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?)\s*$/i);
  if(wd){
    const names=['sun','mon','tue','wed','thu','fri','sat'];
    const target=names.indexOf(wd[1].slice(0,3).toLowerCase());
    const elapsed=(new Date().getDay()-target+7)%7;
    return elapsed===0?null:Math.max(0,elapsed-1);
  }
  return null;
 }
 function anchors(){return [...document.querySelectorAll('a[href]')].filter(a=>/\/marketplace\/t\/|\/messages\/t\/|\/marketplace\/inbox\/\d+/.test(a.getAttribute('href')||''));}
 function rowOf(a){return a.closest('[role="row"],[role="listitem"]')||a.parentElement?.parentElement||a;}
 function scan(){
  if(!validPage()||!selling()||!marketplacePanel())return {error:'Marketplace Selling Messenger list is not verified. No scan performed.'};
  let added=0, dated=0;
  const panel=marketplacePanel();
  const candidates=panel ? anchors().filter(a=>panel.contains(a)) : [];
  for(const a of candidates){
   const row=rowOf(a), raw=norm(row.innerText), d=age(raw);
   if(d===null||!Number.isFinite(d))continue;
   dated++;
   const key=new URL(a.href).pathname;
   if(!seen.has(key))added++;
   seen.set(key,{key,href:a.href,title:raw.slice(0,200),ageDays:d});
  }
  return {added,items:[...seen.values()],diagnostics:{links:candidates.length,dated,weekdayDatesAreConservative:true}};
 }

 // Only interact with clearly identified controls. Never click based on screen position.
 const label=e=>norm(e.getAttribute('aria-label')||e.getAttribute('title')||e.innerText);
 const clickable=e=>e.closest('button,[role="button"],a,[role="menuitem"],[role="tab"]')||e;
 const controls=()=>[...document.querySelectorAll('button,[role="button"],a[aria-label],[role="tab"]')].filter(visible);
 // Navigation is a state machine: re-observe after each action, including navigation.
 const chatHref=/\/marketplace\/t\/|\/messages\/t\/|\/marketplace\/inbox\/\d+/;
 const chatLinks=root=>[...root.querySelectorAll('a[href]')].filter(a=>chatHref.test(a.getAttribute('href')||''));
 // Facebook may render duplicate Messenger controls for responsive layouts.
 // Choose only a control physically hit-testable in the top navigation;
 // never choose an arbitrary first match or click through an overlay.
 const messengerCandidates=()=>[...document.querySelectorAll('[role="button"][aria-label="Messenger"][aria-haspopup="dialog"]')]
   .filter(visible).map(el=>{
     const r=el.getBoundingClientRect();
     const x=r.left+r.width/2, y=r.top+r.height/2;
     const hit=document.elementFromPoint(x,y);
     const actionable=!!hit&&(el===hit||el.contains(hit));
     return {el,r,actionable};
   }).filter(x=>x.r.width>8&&x.r.height>8&&x.r.top>=0&&x.r.top<Math.min(220,innerHeight*.3)&&x.r.right<=innerWidth+2&&x.actionable);
 const messengerButton=()=>{
   const candidates=messengerCandidates();
   if(candidates.length===1)return candidates[0].el;
   if(!candidates.length)return null;
   // Overlapping responsive duplicates are treated as one only if they
   // occupy effectively the same location. Prefer the outer hit-tested control.
   const near=(a,b)=>Math.abs(a.r.left-b.r.left)<3&&Math.abs(a.r.top-b.r.top)<3&&Math.abs(a.r.width-b.r.width)<3&&Math.abs(a.r.height-b.r.height)<3;
   if(candidates.every(x=>near(x,candidates[0])))return candidates[0].el;
   // Multiple distinct top-navigation targets are ambiguous: fail closed.
   return null;
 };
 const messengerOpen=()=>[...document.querySelectorAll('[role="button"][aria-label="Messenger"][aria-haspopup="dialog"]')]
   .filter(visible).some(el=>el.getAttribute('aria-expanded')==='true');
 const messengerDiagnostic=()=>{
   const all=[...document.querySelectorAll('[role="button"][aria-label="Messenger"][aria-haspopup="dialog"]')];
   return `${all.length} matching control(s); ${messengerCandidates().length} hit-testable top-navigation candidate(s)`;
 };
 // Scope Marketplace text to the visible Messenger dialog; never the main page navigation.
 const messengerRoot=()=>{
   if(!messengerOpen())return null;
   const dialogs=[...document.querySelectorAll('[role="dialog"]')].filter(visible)
     .filter(d=>[...d.querySelectorAll('span')].some(x=>visible(x)&&norm(x.textContent)==='Marketplace'));
   return dialogs.length===1?dialogs[0]:null;
 };
 const marketplaceFilter=root=>{
   if(!root)return null;
   const spans=[...root.querySelectorAll('span')].filter(visible).filter(x=>norm(x.textContent)==='Marketplace');
   const targets=[...new Set(spans.map(x=>x.closest('button,[role="button"],[role="tab"],a,[role="menuitem"]')).filter(Boolean))];
   return targets.length===1?targets[0]:null;
 };
 function selectedFilter(el){return !!el && (el.getAttribute('aria-selected')==='true'||el.getAttribute('aria-pressed')==='true'||el.getAttribute('data-state')==='active'||el.getAttribute('aria-current')==='page');}
 function marketplacePanel(){
   const root=messengerRoot();
   if(!root)return null;
   const filter=marketplaceFilter(root);
   if(!filter)return null;
   // Facebook may omit aria-selected on the Marketplace filter. Require chat rows
   // inside the Messenger dialog instead of inferring selection from the main page.
   const links=chatLinks(root);
   if(!links.length)return null;
   // Prefer a visible selected-state indicator; if absent, use a panel whose
   // heading identifies Marketplace, never a generic Chats panel.
   const marked=selectedFilter(filter)||!!filter.closest('[aria-selected="true"],[aria-current="page"],[data-state="active"]');
   const heading=[...root.querySelectorAll('h1,h2,h3,[role="heading"]')].some(x=>/^Marketplace$/i.test(norm(x.textContent)));
   if(!marked&&!heading)return null;
   return root;
 }
 const marketplaceSelected=()=>!!marketplacePanel();
 const navWait=async(check,step,timeout=12000)=>{
   const until=Date.now()+timeout;let consecutive=0;
   while(Date.now()<until){
     if(!validPage())throw Error(step+': Marketplace inbox navigation interrupted');
     if(check()){if(++consecutive>=2)return;}else consecutive=0;
     await sleep(300);
   }
   throw Error(step+': timed out waiting for Facebook to finish rendering');
 };
 function messengerTrigger(){return messengerButton();}
 async function prepareScan(){
   if(!validPage())return {error:'INBOX: Marketplace inbox is not loaded'};
   if(!selling()){
     const tabs=controls().filter(e=>norm(e.innerText)==='Selling');
     if(tabs.length!==1)return {error:'SELLING: Selling tab cannot be identified uniquely'};
     tabs[0].click();
   }
   try{await navWait(selling,'SELLING');}
   catch(e){return {error:e.message};}
   // Recheck sidebar AFTER Selling selection: Facebook may close it.
   if(!messengerOpen()){
     const trigger=messengerTrigger();
     if(!trigger)return {error:'MESSENGER: No unambiguous clickable top-navigation Messenger button ('+messengerDiagnostic()+').'};
     trigger.click();
     try{await navWait(messengerOpen,'MESSENGER');}
     catch(e){return {error:e.message};}
   }
   // Re-evaluate DOM after Messenger loads, rather than reusing stale elements.
   let root=messengerRoot();let filter=marketplaceFilter(root);
   if(!filter)return {error:'MARKETPLACE_FILTER: Could not identify Marketplace inside Messenger uniquely. Select it manually and retry.'};
   if(!marketplaceSelected())filter.click();
   try{await navWait(()=>marketplaceSelected()&&!!marketplacePanel(),'MARKETPLACE_CHATS',15000);}
   catch(e){return {error:e.message};}
   // Final check: all prerequisites must still hold after the last render.
   if(!validPage()||!selling()||!messengerOpen()||!marketplaceSelected()||!marketplacePanel())
     return {error:'FINAL_CHECK: Facebook changed panels during setup; no scan or deletion attempted.'};
   return scan();
 }
 function find(item){return anchors().find(a=>new URL(a.href).pathname===item.key);}
 function panel(){
  let el=document.getElementById('fb-marketplace-cleanup-progress');
  if(el)return el;
  el=document.createElement('aside');el.id='fb-marketplace-cleanup-progress';
  el.style.cssText='position:fixed;right:18px;bottom:18px;z-index:2147483647;background:#fff;color:#111;border:2px solid #555;border-radius:10px;padding:14px;width:340px;box-shadow:0 6px 30px #0005;font:14px Arial';
  const title=document.createElement('strong');title.textContent='FB MarketPlace Messenger Cleanup V1.0';
  const status=document.createElement('p');status.id='fb-marketplace-cleanup-status';status.style.whiteSpace='pre-wrap';
  const cancel=document.createElement('button');cancel.textContent='STOP deletion';cancel.style.cssText='background:#a00;color:white;padding:8px;border:0;border-radius:5px;cursor:pointer';cancel.onclick=()=>{if(!running||stop)return;stop=true;cancel.disabled=true;status.textContent='Stop requested. Finishing current action…';};
  el.append(title,status,cancel);document.body.append(el);return el;
 }
 function update(s){const p=panel().querySelector('#fb-marketplace-cleanup-status');p.textContent=s;}
 function closePanel(){document.getElementById('fb-marketplace-cleanup-progress')?.remove();}
 function visible(el){return el&&el.getClientRects().length>0;}
 function named(root,selector,pattern){return [...root.querySelectorAll(selector)].filter(el=>visible(el)&&pattern.test(norm(el.getAttribute('aria-label')||el.innerText)));}
 async function deleteOne(item,threshold){
  if(!validPage()||!selling()||!(marketplacePanel()||marketplaceSelected()))throw Error('Marketplace Messenger filter not verified; deletion blocked');
  const a=find(item);if(!a)throw Error('Row not currently visible (scroll it into view and rescan)');
  const row=rowOf(a), currentAge=age(norm(row.innerText));
  if(currentAge===null||currentAge<threshold)throw Error('Age could not be reconfirmed');
  a.scrollIntoView({block:'center'});a.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));await sleep(350);
  // Only use a menu button associated with this specific row. Never use a global More menu.
  let container=row, menu=[];
  for(let i=0;i<4&&container;i++,container=container.parentElement){
   menu=named(container,'button,[role="button"]',/^More options for\b/i);
   if(menu.length===1)break;
  }
  if(menu.length!==1){
    const buttons=[...row.querySelectorAll('button,[role="button"]')].map(el=>norm(el.getAttribute('aria-label')||el.innerText)).filter(Boolean).slice(0,12);
    throw Error('ROW_MENU: expected one More options for button; found '+menu.length+'. Row button labels: '+JSON.stringify(buttons));
   }
  menu[0].click();await sleep(350);
  const options=named(document,'[role="menuitem"]',/^Delete chat$/i);
  if(options.length!==1){const labels=[...document.querySelectorAll('[role="menuitem"]')].filter(visible).map(el=>norm(el.getAttribute('aria-label')||el.innerText)).slice(0,15);throw Error('DELETE_MENU: expected one Delete chat item; found '+options.length+'. Visible menu labels: '+JSON.stringify(labels));}
  options[0].click();await sleep(350);
  // Facebook may keep multiple dialog containers in the DOM, including nested
  // dialogs. Select the ONE visible, enabled confirmation button inside a
  // dialog whose own text describes deletion. Never choose a global Delete.
  const dialogs=[...document.querySelectorAll('[role="dialog"],[role="alertdialog"]')].filter(visible);
  const candidates=[];
  for(const dialog of dialogs){
   const dialogText=norm(dialog.innerText);
   if(!/delete (?:this )?chat|delete conversation|delete (?:this )?conversation/i.test(dialogText))continue;
   for(const button of named(dialog,'button,[role="button"]',/^Delete( chat| conversation)?$/i)){
    if(button.disabled||button.getAttribute('aria-disabled')==='true')continue;
    if(!candidates.includes(button))candidates.push(button);
   }
  }
  // Nested dialogs can expose the same button through multiple ancestors;
  // the deduplication above handles that. More than one distinct button is unsafe.
  if(candidates.length!==1){
   const descriptions=dialogs.map(d=>norm(d.innerText).slice(0,140));
   throw Error('CONFIRM_DIALOG: '+dialogs.length+' visible dialog(s), '+candidates.length+' unique matching Delete button(s). Dialog text: '+JSON.stringify(descriptions));
  }
  // Abort if the original row changed or the user navigated while the dialog opened.
  if(!validPage()||!selling()||!find(item))throw Error('VERIFY_BEFORE_CONFIRM: Selling inbox or selected row changed');
  candidates[0].click();await sleep(1200);
  if(find(item))throw Error('VERIFY: confirmation clicked, but row still visible; deletion not verified');
  seen.delete(item.key);return true;
 }
 async function run(keys,threshold){
  if(running)return {error:'A deletion is already running'};
  if(!validPage()||!selling()||!(marketplacePanel()||marketplaceSelected()))return {error:'Marketplace Messenger filter not verified; deletion blocked'};
  if(!Array.isArray(keys)||!Number.isInteger(threshold)||threshold<1||threshold>3650)return {error:'Invalid request'};
  running=true;stop=false;report=[];lastFailure='';lastSummary=null;
  const unique=[...new Set(keys)].filter(k=>seen.has(k));
  update(`Starting ${unique.length} selected conversations. Keep this Facebook tab open.`);
  for(let i=0;i<unique.length;i++){
   if(stop)break;
   const item=seen.get(unique[i]);if(!item)continue;
   update(`${i+1}/${unique.length}: ${item.title.slice(0,90)}`);
   try{await deleteOne(item,threshold);report.push({title:item.title,ageDays:item.ageDays,status:'deleted'});}
   catch(e){lastFailure=String(e.message||e);report.push({title:item.title,ageDays:item.ageDays,status:'not verified: '+lastFailure});stop=true;}
   await sleep(900);
  }
  running=false;
  const deleted=report.filter(x=>x.status==='deleted').length;
  lastSummary={deleted,stopped:stop,report:[...report],failure:lastFailure,completedAt:new Date().toISOString()};
  closePanel(); // Always dismiss floating overlay when batch ends or stops.
  return lastSummary;
 }
 chrome.runtime.onMessage.addListener((msg,_sender,reply)=>{
  if(msg?.type==='scan')reply(scan());
  else if(msg?.type==='prepareScan'){prepareScan().then(reply).catch(e=>reply({error:e.message}));return true;}
  else if(msg?.type==='get')reply({items:[...seen.values()],running,report,failure:lastFailure,lastSummary});
  else if(msg?.type==='stop'){stop=true;reply({ok:true});}
  else if(msg?.type==='delete'){
   // Explicit user approval occurs in popup, not in the page itself.
   run(msg.keys,msg.days).then(reply).catch(e=>{running=false;closePanel();reply({error:e.message});});return true;
  }else reply({error:'Unknown command'});
  return false;
 });
})();
